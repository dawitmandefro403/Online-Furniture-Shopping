#include <iostream>
#include<gl/glut.h>


void display(){
	glClear(GL_COLOR_BUFFER_BIT);
	glClearColor(0.0,0.0,0.0,0.0);

 //POLL
    glColor3f(0.9,0.8,0.8);
    glBegin(GL_QUADS);
    glVertex2f(-0.44,0.72);
    glVertex2f(-0.42,0.72);
    glVertex2f(-0.42,-0.9);
    glVertex2f(-0.44,-0.9);
    glEnd();
    
    glColor3f(0.9,0.8,0.8);
    glBegin(GL_TRIANGLES);
    glVertex2f(-0.43,0.78);
    glVertex2f(-0.42,0.72);
    glVertex2f(-0.44,0.72);
    glEnd();
    
    
        glBegin(GL_QUADS);
    glVertex2f(-0.5,-0.9);
    glVertex2f(-0.32,-0.9);
    glVertex2f(-0.32,-0.96);
    glVertex2f(-0.5,-0.96);
    glEnd();
	
	        glBegin(GL_QUADS);
    glVertex2f(-0.52,-0.96);
    glVertex2f(-0.3,-0.96);
    glVertex2f(-0.3,-1.2);
    glVertex2f(-0.52,-1.2);
    glEnd();
    
        glColor3f(1,1,1);
    glBegin(GL_QUADS);
    glVertex2f(-0.42,0.7);
    glVertex2f(0.34,0.7);
    glVertex2f(0.34,0.5);
    glVertex2f(-0.42,0.5);
    glEnd();
    
        glColor3f(0,0,1);
    glBegin(GL_QUADS);
    glVertex2f(-0.42,0.5);
    glVertex2f(0.34,0.5);
    glVertex2f(0.34,0.3);
    glVertex2f(-0.42,0.3);
    glEnd();
    
        glColor3f(1,0,0);
    glBegin(GL_QUADS);
    glVertex2f(-0.42,0.3);
    glVertex2f(0.34,0.3);
    glVertex2f(0.34,0.1);
    glVertex2f(-0.42,0.1);
    glEnd();
    
    glFlush();
}

int main(int argc, char** argv) {
	
	glutInit(&argc,argv);
	glutInitWindowSize(600,500);
	glutInitWindowPosition(50,50);
	
	glutCreateWindow("Flag of Russia");
	glutDisplayFunc(display);
	glutMainLoop();
	return 0;
}
